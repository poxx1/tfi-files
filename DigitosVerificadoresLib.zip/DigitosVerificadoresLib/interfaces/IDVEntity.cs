﻿using System;

namespace DigitosVerificadoresLib.interfaces
{
	public interface IDVEntity
	{
        String dvh
		{
			get;
			set;
		}
	}
}